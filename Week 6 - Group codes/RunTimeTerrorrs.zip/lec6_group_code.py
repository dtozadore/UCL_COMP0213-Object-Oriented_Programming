import random, calendar
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# Creating a dictionary to store data
data = {'Customer Name': [], 'Customer ID': [], 'Day': [], 'Month': [], 'Value': []}

# Creating arrays for Customer Name and Customer IDs
names = ['Artemis', 'Bob', 'Charlie', 'David', 'Eesha', 'Fiona', 'George', 'Harry', 'India', 'Jack', 'Keira', 'Lakshaya', 'Mac', 'Neo', 'Vin']
customer_id = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
year = 2025

# Nested loop to generate data per customer per month
for i in range(15):
    for j in range(50):
        data['Customer Name'].append(names[i])
        data['Customer ID'].append(customer_id[i])

        amount = round(random.uniform(-15, 15), 2)
        data['Value'].append(amount)

        month = random.randint(1, 12)
        data['Month'].append(month)

        day = random.randint(1, calendar.monthrange(year, month)[1])
        data['Day'].append(day)

# Dict to Dataframe to CSV
frame = pd.DataFrame(data)
frame_csv = frame.to_csv('daily_entries.csv')

col_names = ['name', 'id', 'day', 'month', 'value']
extracted = pd.read_csv("daily_entries.csv", header=None, names=col_names)

# Part 2A
# group the customers’ balance per month and move it in another Data frame
def compute_monthly_balance(extracted):

    # New dict for a customer's monthly balance
    monthly_balance = {'Customer Name': [], 'Month': [], 'Balance': []}

    for i in range(15):
        # Initialise every month per customer at 0
        balance = np.zeros(12)

        for j in range(50):
            # Extracting the value for a customer
            balance[int(extracted.month[i*50 + j])-1] += float(extracted.value[i*50 + j])
        
        for k in range(12):
            # Append the dict with extacted information
            monthly_balance['Customer Name'].append(extracted.name[i*50])
            monthly_balance['Month'].append(k+1)
            monthly_balance['Balance'].append(balance[k])

    return monthly_balance

# Dict to Dataframe to CSV file
data2 = compute_monthly_balance(extracted)
frame2 = pd.DataFrame(data2)
frame_csv2 = frame2.to_csv('monthly_balances.csv')

# Part 2B
# Function to add noise
def add_noise(data, std_dev):
    noisy_data = data.copy()
    keys = list(data.keys())
    length = len(data[keys[0]])
    
    for i in range(length):
        noisy_data[keys[-1]][i] += np.random.normal(0, std_dev)

    return noisy_data

# Dict to Dataframe to CSV file
data3 = add_noise(data, 0.01)
frame3 = pd.DataFrame(data3)
frame_csv3 = frame3.to_csv('daily_entries_noisy.csv')

# Part 2C
col_names = ['name', 'id', 'day', 'month', 'value']
extracted2 = pd.read_csv("daily_entries_noisy.csv", header=None, names=col_names)

# Dict to Dataframe to CSV file
data4 = compute_monthly_balance(extracted2)
frame4 = pd.DataFrame(data4)
frame_csv4 = frame4.to_csv('monthly_balances_noisy.csv')

# Combining the 2 datasets
frames = [frame, frame3]
combine_daily_dailynoise = pd.concat(frames)
frame_csv5 = combine_daily_dailynoise.to_csv('daily_entries_total.csv')

# Part 3
# Load the data from Part 2C
def load_data(filepath="daily_entries_total.csv"):
    df_part3 = pd.read_csv(filepath)
    return df_part3


def add_date_column(df_part3):
    df_part3 = df_part3.copy()
    df_part3["Date"] = df_part3.apply(lambda row: datetime(2025, int(row["Month"]), int(row["Day"])), axis=1)
    return df_part3

# Given a customer name or ID, plots all the entries of that customer.
def plot_customer_entries(df_part3, customer):
    df_part3 = add_date_column(df_part3)
    
    # Accepting both ID or customer name
    comb = df_part3[(df_part3["Customer Name"] == customer) | (df_part3["Customer ID"] == customer)]

    # Sort by date
    comb = comb.sort_values("Date")

    # Plotting all entries for that customer in time order
    plt.figure()
    plt.plot(comb["Date"], comb["Value"], marker='o')
    plt.title(f"Entries for Customer: {customer}")
    plt.xlabel("Date")
    plt.ylabel("Transaction Value")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# Given a day of the year (with the month), plots all the entries on that day.
def plot_entries_by_day(df_part3, day, month):
    comb = df_part3[(df_part3["Day"] == day) & (df_part3["Month"] == month)]

    # If date does not exist in dataframe, raise exception
    if comb.empty:
        raise Exception("No entries for inputted date")

    # Plotting bar chart
    plt.figure()
    plt.bar(comb["Customer Name"], comb["Value"])
    plt.title(f"Entries on {day}/{month}")
    plt.xlabel("Customer")
    plt.ylabel("Transaction Value")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Given a customer name or ID, plots the balance of that customer per month in grouped column bars
def plot_customer_balance_pm(df_part3, customer):
    comb = df_part3[(df_part3["Customer Name"] == customer) | (df_part3["Customer ID"] == customer)]

    # Groups all rows that have the same month, select value in group col, add them all up
    group_months = comb.groupby("Month")        
    values_per_month = group_months["Value"]         
    monthly_balance = values_per_month.sum()   

    # Plotting grouped column bars
    plt.figure()
    plt.bar(monthly_balance.index, monthly_balance.values)
    plt.title(f"Monthly Balance for Customer: {customer}")
    plt.xlabel("Month of Year")
    plt.ylabel("Total Balance")
    plt.xticks(monthly_balance.index)
    plt.tight_layout()
    plt.show()

# Given a starting and ending date, plots all the entries within this period per customer
def plot_entries_in_range(df_part3, start_day, start_month, end_day, end_month):
    df_part3 = add_date_column(df_part3)
    start_date = datetime(2025, start_month, start_day)
    end_date = datetime(2025, end_month, end_day)

    # Set start and end dates (create the range logic)
    comb = df_part3[(df_part3["Date"] >= start_date) & (df_part3["Date"] <= end_date)]

    # If dates (in the given range) do not exist in dataframe, raise exception
    if comb.empty:
        raise Exception("No entries found in this date range.")

    # Group customer and date, get the value, add all values together, and make a table/df
    group_data = comb.groupby(["Customer Name", "Date"])
    group_vals = group_data["Value"]
    sum_of_vals = group_vals.sum()
    table = sum_of_vals.unstack(fill_value=0)

    # Plotting
    table.T.plot(kind="line", marker="o")
    plt.title(f"Entries per Customer from {start_date.date()} to {end_date.date()}")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# Given a starting and ending date, plots all the negative transactions within that period
def plot_neg_entries_in_range(df_part3, start_day, start_month, end_day, end_month):
    df_part3 = add_date_column(df_part3)
    start_date = datetime(2025, start_month, start_day)
    end_date = datetime(2025, end_month, end_day)
    
    # Set start and end dates (create the range logic)
    # Same as plot_entries_in_range() but with additional condition in comb to get negative entries
    comb = df_part3[(df_part3["Date"] >= start_date) & (df_part3["Date"] <= end_date) & (df_part3['Value'] < 0)]

    # If dates (in the given range) do not exist in dataframe, raise exception
    if comb.empty:
        raise Exception("No negative entries found in this date range.")

    # Group customer and date, get the value, add all values together, and make a table/df
    group_data = comb.groupby(["Customer Name", "Date"])
    group_vals = group_data["Value"]
    sum_of_vals = group_vals.sum()
    table = sum_of_vals.unstack(fill_value=0)

    # Plotting
    table.T.plot(kind="line", marker="o")
    plt.title(f"Entries per Customer from {start_date.date()} to {end_date.date()}")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid(True)
    plt.tight_layout()
    plt.show()


df_part3 = load_data()
plot_customer_entries(df_part3, "Artemis")
plot_entries_by_day(df_part3, 11, 7)
plot_customer_balance_pm(df_part3, "Artemis")
plot_entries_in_range(df_part3, 1, 1, 15, 1)
plot_neg_entries_in_range(df_part3, 1, 1, 15, 1)

# Part 4


    


    