from login import login
from data_generator import generation, noise
from dataset_handler import DatasetHandler
from data_plotter import DataPlotter
import pandas as pd
import datetime

if __name__ == "__main__":
    # Generate datasets
    customer_names = (('Xavier',1),('Han Se',2),('Peter',3),('Aryan',4),('Yash',5),('Edwin',6),('Tara',7),('Tom',8),('Kishan',9),('Daniel',10),('Igor',11),('Andrew',12),('Jeson',13),('Tim',14),('Aayan',15))
    year = 2025
    n_entries = 50

    # Simple dataset
    df1 = generation(year, n_entries, customer_names)
    dataset_handler1 = DatasetHandler("daily_entries.csv")
    dataset_handler1.save_dataset(df1, "daily_entries.csv")

    # Noisy dataset
    df2 = generation(year, n_entries, customer_names)
    df2 = noise(df2)
    dataset_handler2 = DatasetHandler("daily_entries_2.csv")
    dataset_handler2.save_dataset(df2, "daily_entries_2.csv")

    # Load datasets
    daily_entries_df1 = dataset_handler1.load_dataset()
    daily_entries_df2 = dataset_handler2.load_dataset()

    # Combine datasets and save
    daily_entries_df = pd.concat([daily_entries_df1, daily_entries_df2], ignore_index=True)
    dataset_handler1.save_dataset(daily_entries_df, "daily_entries_total.csv")

    # Group balances by month and save
    monthly_balances_df = dataset_handler1.group_balances_by_month(daily_entries_df)
    dataset_handler1.save_dataset(monthly_balances_df, "monthly_balances.csv")

    # Plot data for a specific customer
    dp = DataPlotter(
      pd.read_csv("daily_entries_total.csv"),
      pd.read_csv("monthly_balances.csv"))
    dp.plot_day(10, 5)
    dp.plot_customer("Xavier")
    dp.plot_customer_months("Han Se")

    dp.plot_date_range(datetime.date(2025, 3, 1), datetime.date(2025, 8, 1))

    # Login examples with different user types
    bank_manager_data = login("Bank Manager")
    data_analyst_data = login("Data analyst")
    customer_data = login("Customer", name="Edwin")

    print("Bank Manager Data:")
    print(bank_manager_data.head())

    print("Data Analyst Data:")
    print(data_analyst_data.head())

    print("Customer Data:")
    print(customer_data.head())