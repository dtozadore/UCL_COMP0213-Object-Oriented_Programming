import pandas as pd
import random
import calendar
import matplotlib as plt
import numpy as np

random.seed = 0    

def generation(year, n_entries,  customer_names):
    df = pd.DataFrame({"Name": [], "CustomerID": [], "Day": [], "Month": [], "Amount": []})

    for customer, id in customer_names:
        amounts = [random.randint(-15, 15) for i in range(n_entries)]
        months = np.random.randint(1, 12, (n_entries,))
        days = [random.randint(1, calendar.monthrange(year, month)[1]) for month in months]
        temp = pd.DataFrame({"Name": [customer]*n_entries, "CustomerID": [id]*n_entries, "Day": days, "Month": months, "Amount":amounts})
        df = df.merge(temp,how="outer")
    return df

def noise(df, n_noise = None):
    if n_noise == None:
        n_noise = random.randint(10, 40)
    for i in range(n_noise):
        y = random.randint(0,len(df)-1)
        x = random.randint(0, (df.size/len(df))-1)
        if df.iloc[y, x] != "NaN": df.iloc[y, x] = "NaN"
        else: n_noise += 1
    return df


customer_names = (('Xavier',1),('Han Se',2),('Peter',3),('Aryan',4),('Yash',5),('Edwin',6),('Tara',7),('Tom',8),('Kishan',9),('Daniel',10),('Igor',11),('Andrew',12),('Jeson',13),('Tim',14),('Aayan',15))
year = 2025
n_entries = 50
df = generation(year, n_entries, customer_names)
df = noise(df)
# df.to_csv("daily_entries2.csv")