import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import matplotlib.dates as mdates
import datetime


class DataPlotter():
  def __init__(self, entry_data, monthly_data):
    self.data = entry_data
    self.data.dropna(inplace=True)

    self.month = monthly_data
    self.month.dropna(inplace=True)

  def get_customer(self,
                   customer_name=None,
                   id=None,
                   min_date=None,
                   max_date=None):
    if id:
      customer = self.data[self.data["CustomerID"] == id]  # type: ignore
    elif customer_name:
      customer = self.data.loc[self.data["Name"]
                               == customer_name]  # type: ignore
    else:
      return (None, None)  # Error, replace with better message when MVC

    customer = customer.sort_values(by=['Month', 'Day'], ascending=True)

    # Data to plot
    cumulative = np.cumsum(customer["Amount"])
    dt = [datetime.date(year=2025, month=int(customer.at[i, "Month"]), day=int(
      customer.at[i, "Day"])) for i in customer.index]

    if min_date:
      for i in range(len(dt)):
        if dt[i] > min_date:
          dt = dt[i:]
          cumulative = cumulative[i:]
          break
    if max_date:
      for i in range(len(dt) - 1, 0, -1):
        if dt[i] < max_date:
          dt = dt[:i]
          cumulative = cumulative[:i]
          break
    return (dt, cumulative)

  def plot_customer(
          self,
          customer_name=None,
          id=None,
          min_date=None,
          max_date=None):

    dt, cumulative = self.get_customer(customer_name, id, min_date, max_date)

    fig, ax = plt.subplots()
    ax.plot(dt, cumulative)  # type: ignore
    ax.format_xdata = mdates.DateFormatter('%DD:%MM:%YY')
    plt.xticks(rotation=45)
    ax.set_title(f"Balance: {customer_name}")
    ax.set_xlabel("Date")
    ax.set_ylabel("Amount")
    fig.tight_layout()
    plt.show()
    plt.close(fig)

  def plot_date_range(self, min_date, max_date):
    people = [*set(self.data["Name"])]

    fig, ax = plt.subplots()
    for person in people:
      dt, cumulative = self.get_customer(
          customer_name=person, min_date=min_date, max_date=max_date)
      ax.plot(dt, cumulative)  # type: ignore

    ax.format_xdata = mdates.DateFormatter('%DD:%MM:%YY')
    plt.xticks(rotation=45)
    ax.set_title(f"Balances")
    ax.set_xlabel("Date")
    ax.set_ylabel("Amount")
    ax.legend(people)
    fig.tight_layout()
    plt.show()
    plt.close(fig)

  def plot_day(self, day, month):
    transactions = self.data.loc[(self.data["Month"]
                                 == month) * (self.data["Day"] == day)]

    # Convert to a dataframe, which means the plot can be generated
    # automatically
    # The people with transactions on this day
    people = [*set(transactions["Name"])]
    multiplier = 0
    width = 0.25
    fig, ax = plt.subplots()
    for person in people:
      person_data = transactions.loc[(transactions["Name"] == person)]

      offset = width * multiplier
      x = np.arange(len(person_data))
      rects = ax.bar(x + offset, person_data["Amount"], width)
      ax.bar_label(rects, padding=3)
      multiplier += 1
    ax.set_xticks(np.arange(len(people)) / multiplier, people)

    ax.set_title(f"Daily transfers: ({day:02d}/{month:02d})")
    plt.show()
    plt.close(fig)

  def plot_customer_months(self, customer_name=None, id=None):
    if id:
      customer = self.month[self.month["CustomerID"] == id]  # type: ignore
    elif customer_name:
      customer = self.month.loc[self.month["Name"] == customer_name]
    else:
      return -1  # Error, replace with better message when MVC

    fig, ax = plt.subplots()
    ax.bar(customer["Month"], customer["Amount"])
    ax.set_title(f"Monthly Balance: {customer_name}")
    ax.set_xlabel("Month")
    ax.set_ylabel("Amount")
    fig.tight_layout()
    plt.show()
    plt.close(fig)


if __name__ == "__main__":
  dp = DataPlotter(
      pd.read_csv("daily_entries_total.csv"),
      pd.read_csv("monthly_balances.csv"))
  dp.plot_day(10, 5)
  dp.plot_customer("Xavier")
  dp.plot_customer_months("Han Se")

  dp.plot_date_range(datetime.date(2025, 3, 1), datetime.date(2025, 8, 1))
