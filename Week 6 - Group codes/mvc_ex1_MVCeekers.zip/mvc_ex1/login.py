import pandas as pd

def login(type: str, name = None):
    if type == "Bank Manager":
        df = pd.read_csv("daily_entries_total.csv")
    if type == "Data analyst":
        df = pd.read_csv("daily_entries_total.csv")
        df = df.drop('Name', axis=1)
    if type == "Customer":
        df = pd.read_csv("daily_entries_total.csv")
        df = df.loc[df["Name"] == name]

    return df