import pandas as pd

class DatasetHandler:
    def __init__(self, filepath):
        self.filepath = filepath

    def load_dataset(self):
        return pd.read_csv(self.filepath)
    
    def save_dataset(self, df, output_filepath):
        df.to_csv(output_filepath, index=False)
    
    def group_balances_by_month(self, df):
        # For each customer and month, sum the amounts (accounting for NaN values)
        df['Amount'] = df['Amount'].fillna(0)
        monthly_balances = df.groupby(['Name', 'CustomerID', 'Month'])['Amount'].sum().reset_index()
        return monthly_balances

if __name__ == "__main__":
    # Load the daily entries datasets
    dataset_handler1 = DatasetHandler("daily_entries.csv")
    daily_entries_df1 = dataset_handler1.load_dataset()

    dataset_handler2 = DatasetHandler("daily_entries_2.csv")
    daily_entries_df2 = dataset_handler2.load_dataset()

    # Combine the two datasets and save the total daily entries (make numerical values integers)
    daily_entries_df = daily_entries_df1.merge(daily_entries_df2, how="outer")
    daily_entries_df['Amount'] = daily_entries_df['Amount'].fillna(0).astype(int)
    dataset_handler1.save_dataset(daily_entries_df, "daily_entries_total.csv")
    
    # Group balances by month
    monthly_balances_df = dataset_handler1.group_balances_by_month(daily_entries_df)
    dataset_handler1.save_dataset(monthly_balances_df, "monthly_balances.csv")
