from controller.app_controller import AppController

app = AppController()

# Login examples:
# app.login("MANAGER")
# app.login("ANALYST")
# app.login("CUSTOMER", customer_id="483921")

app.login("MANAGER")

app.show_customer_entries("Bob")
#app.show_negative_period(3,1,5,30)
