import pandas as pd


class DataModel:
    def __init__(self, path="daily_entries_total.csv"):
        self.df_total = pd.read_csv(path)

    # Helper: filter by name or ID
    def filter_customer(self, identifier):
        df = self.df_total
        if identifier in df["Customer_Name"].values:
            return df[df["Customer_Name"] == identifier]

        if identifier in df["Customer_ID"].astype(str).values:
            return df[df["Customer_ID"].astype(str) == identifier]

        raise ValueError("Customer not found")

    def get_customer_entries(self, identifier):
        return self.filter_customer(identifier)

    def get_entries_by_day(self, day, month):
        df_day = self.df_total[(self.df_total["Day"] == day) &
                               (self.df_total["Month"] == month)]
        return df_day

    def get_monthly_balance(self, identifier):
        df_c = self.filter_customer(identifier)
        return df_c.groupby("Month")["Value"].sum().reset_index()

    def get_entries_period(self, start_m, start_d, end_m, end_d):
        df = self.df_total.copy()
        df["Key"] = df["Month"] * 100 + df["Day"]
        s = start_m * 100 + start_d
        e = end_m * 100 + end_d
        return df[(df["Key"] >= s) & (df["Key"] <= e)]

    def get_negative_period(self, start_m, start_d, end_m, end_d):
        df = self.get_entries_period(start_m, start_d, end_m, end_d)
        return df[df["Value"] < 0]
