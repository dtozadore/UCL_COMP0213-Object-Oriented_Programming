import matplotlib.pyplot as plt


class PlotView:

    def plot_customer_entries(self, df, identifier):
        plt.figure()
        plt.plot(df["Value"])
        plt.title(f"All Entries for {identifier}")
        plt.xlabel("Index")
        plt.ylabel("Value")
        plt.grid(True)
        plt.show()

    def plot_entries_by_day(self, df, day, month):
        plt.figure()
        plt.bar(range(len(df)), df["Value"])
        plt.title(f"Entries on {day}/{month}")
        plt.xlabel("Index")
        plt.ylabel("Value")
        plt.grid(True)
        plt.show()

    def plot_monthly_balance(self, df, identifier):
        plt.figure()
        plt.bar(df["Month"], df["Value"])
        plt.title(f"Balance per Month for {identifier}")
        plt.xlabel("Month")
        plt.ylabel("Balance")
        plt.grid(True)
        plt.show()

    def plot_period_per_customer(self, df):
        plt.figure()
        for name, group in df.groupby("Customer_Name"):
            plt.plot(group["Key"], group["Value"], label=name)
        plt.title("Entries per Customer (Period)")
        plt.xlabel("Date Key")
        plt.ylabel("Value")
        plt.legend()
        plt.grid(True)
        plt.show()

    def plot_negatives(self, df):
        plt.figure()
        plt.scatter(df["Key"], df["Value"])
        plt.title("Negative Transactions in Period")
        plt.xlabel("Date Key")
        plt.ylabel("Value")
        plt.grid(True)
        plt.show()
