from model.data_model import DataModel
from view.plot_view import PlotView


class AppController:

    def __init__(self):
        self.model = DataModel()
        self.view = PlotView()
        self.user_role = None
        self.customer_id = None  # needed if user = CUSTOMER

    def login(self, role, customer_id=None):
        self.user_role = role
        self.customer_id = customer_id

    # ---- Helper to apply role restrictions ----
    def _check_access_customer(self, identifier):
        if self.user_role == "CUSTOMER" and identifier != self.customer_id:
            raise PermissionError("Customers can only view their own data.")

    def _remove_names_for_analyst(self, df):
        if self.user_role == "ANALYST":
            df = df.drop(columns=["Customer_Name"])
        return df

    # ---------------------------------------------------------
    def show_customer_entries(self, identifier):
        self._check_access_customer(identifier)
        df = self.model.get_customer_entries(identifier)
        df = self._remove_names_for_analyst(df)
        self.view.plot_customer_entries(df, identifier)

    def show_day_entries(self, day, month):
        df = self.model.get_entries_by_day(day, month)
        if df.empty:
            raise Exception("No entries for that day")
        df = self._remove_names_for_analyst(df)
        self.view.plot_entries_by_day(df, day, month)

    def show_monthly_balance(self, identifier):
        self._check_access_customer(identifier)
        df = self.model.get_monthly_balance(identifier)
        df = self._remove_names_for_analyst(df)
        self.view.plot_monthly_balance(df, identifier)

    def show_entries_period(self, sm, sd, em, ed):
        df = self.model.get_entries_period(sm, sd, em, ed)
        df = self._remove_names_for_analyst(df)
        self.view.plot_period_per_customer(df)

    def show_negative_period(self, sm, sd, em, ed):
        df = self.model.get_negative_period(sm, sd, em, ed)
        df = self._remove_names_for_analyst(df)
        self.view.plot_negatives(df)
