import pandas as pd

def save_daily_entries(df):
    df.to_csv("daily_entries.csv", index=False)

def load_daily_entries():
    return pd.read_csv("daily_entries.csv")

def compute_monthly_balances(df):
    grouped = df.groupby(["Name", "ID", "Month"])["Value"].sum().reset_index()
    monthly_data = {"Name": [], "ID": [], "Month": [], "Total_Balance": []}
    for _, row in grouped.iterrows():
        monthly_data["Name"].append(row["Name"])
        monthly_data["ID"].append(row["ID"])
        monthly_data["Month"].append(row["Month"])
        monthly_data["Total_Balance"].append(round(row["Value"], 2))
    return pd.DataFrame(monthly_data)

def save_monthly_balances(df):
    df.to_csv("monthly_balances.csv", index=False)

def load_monthly_balances():
    return pd.read_csv("monthly_balances.csv")
