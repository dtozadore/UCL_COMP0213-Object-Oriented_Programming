current_user_type = "BankManager"
current_user = None

def login(user_type, user_identifier=None):
    global current_user_type, current_user
    current_user_type = user_type
    current_user = user_identifier
    print(f"Logged in as {user_type}" + (f" ({user_identifier})" if user_identifier else ""))
