def authorize_request(df, user_type, current_user):
    if user_type == "BankManager":
        return df
    elif user_type == "Customer":
        return df[(df["Name"] == current_user) | (df["ID"] == current_user)]
    elif user_type == "DataAnalyst":
        df2 = df.copy()
        df2["Name"] = "REDACTED"
        return df2
    else:
        raise ValueError("Invalid role")
