import pandas as pd
import random
import calendar

year = 2025
customer_infos = [f"Customer_{i}" for i in range(1, 16)]
customer_ids = [f"ID00{i}" for i in range(1, 16)]

data = {"Name": [], "ID": [], "Day": [], "Month": [], "Value": []}

def generate_data():
    for info, cid in zip(customer_infos, customer_ids):
        for _ in range(50):
            month = random.randint(1, 12)
            day = random.randint(1, calendar.monthrange(year, month)[1])
            value = round(random.uniform(-15, 15), 2)
            data["Name"].append(info)
            data["ID"].append(cid)
            data["Day"].append(day)
            data["Month"].append(month)
            data["Value"].append(value)
    df = pd.DataFrame(data)
    df.to_csv("daily_entries.csv", index=False)
    return df
