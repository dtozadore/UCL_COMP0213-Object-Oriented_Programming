import pandas as pd

def update_monthly_balances(noisy_file, monthly_file):
    df_noisy = pd.read_csv(noisy_file)
    df_noisy.dropna()
    print("Dropped NaN values from noisy data")
    grouped_noisy = df_noisy.groupby(["Name", "ID", "Month"])["Value"].sum().reset_index()
    monthly_data_updated = {"Name": [], "ID": [], "Month": [], "Total_Balance": []}
    for _, row in grouped_noisy.iterrows():
        monthly_data_updated["Name"].append(row["Name"])
        monthly_data_updated["ID"].append(row["ID"])
        monthly_data_updated["Month"].append(row["Month"])
        monthly_data_updated["Total_Balance"].append(round(row["Value"], 2))
    monthly_df_updated = pd.DataFrame(monthly_data_updated)
    monthly_df_updated.to_csv("monthly_balances_updated.csv", index=False)
    return monthly_df_updated
