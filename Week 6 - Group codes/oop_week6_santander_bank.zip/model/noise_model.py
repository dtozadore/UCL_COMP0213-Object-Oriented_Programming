import random
import pandas as pd

def add_noise(df, fraction=0.05):
    df_noisy = df.copy()
    n_rows, n_cols = df_noisy.shape
    total_cells = n_rows * n_cols
    num_noise = int(total_cells * fraction)
    for _ in range(num_noise):
        row = random.randint(0, n_rows - 1)
        col = random.randint(0, n_cols - 1)
        df_noisy.iat[row, col] = "NaN"
    return df_noisy
