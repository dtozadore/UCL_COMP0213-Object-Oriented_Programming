from model.data_model import generate_data, data
from model.noise_model import add_noise
from model.update_model import update_monthly_balances
from controller.data_controller import (
    save_daily_entries, load_daily_entries,
    compute_monthly_balances, save_monthly_balances
)
from controller.access_controller import authorize_request
from controller.user_controller import login, current_user_type, current_user
from view.plotting_view import (
    plot_customer_entries, plot_entries_day, plot_customer_balance_month,
    plot_entries_between_dates, plot_negative_transactions_between_dates
)

df = generate_data()
save_daily_entries(df)

monthly_df = compute_monthly_balances(df)
save_monthly_balances(monthly_df)

df2_noisy = add_noise(df, fraction=0.05)
df2_noisy.to_csv("daily_entries_2.csv", index=False)
update_monthly_balances("daily_entries_2.csv", "monthly_balances.csv")

login("DataAnalyst")

df_loaded = load_daily_entries()
df_visible = authorize_request(df_loaded, current_user_type, current_user)

plot_customer_entries(df_visible, "Customer_1")
plot_entries_day(df_visible, day_num=15, month=5)
plot_customer_balance_month(df_visible, "Customer_1")   
plot_entries_between_dates(df_visible, "Customer_1", "2025-03-01", "2025-06-30")
plot_negative_transactions_between_dates(df_visible, "2025-01-01", "2025-12-31")