import pandas as pd
import matplotlib.pyplot as plt

def plot_customer_entries(df, customer_info):
    customer_df = df[(df["Name"] == customer_info) | (df["ID"] == customer_info)]
    if customer_df.empty:
        print(f"No entries found for customer: {customer_info}")
        return
    customer_df['Date'] = pd.to_datetime(dict(year=2025, month=customer_df['Month'], day=customer_df['Day']))
    plt.figure()
    plt.scatter(customer_df['Date'], customer_df['Value'], marker='o')
    plt.title(f"Entries for {customer_info}")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid()
    plt.show()

def plot_entries_day(df, day_num, month):
    day_df = df[(df["Day"] == day_num) & (df["Month"] == month)]
    if day_df.empty:
        
        print("No entries made on that particular day")
        return
    plt.figure()
    plt.bar(day_df['Name'], day_df['Value'])
    plt.title(f"Entries on Day {day_num} of Month {month}")
    plt.xlabel("Customer Entries")
    plt.ylabel("Value")
    plt.grid()
    plt.show()

def plot_customer_balance_month(df, customer_info):
    customer_df = df[(df["Name"] == customer_info) | (df["ID"] == customer_info)]
    if customer_df.empty:
        print(f"No entries found for customer: {customer_info}")
        return
    monthly_balance = customer_df.groupby("Month")["Value"].sum().reset_index()
    plt.figure()
    plt.bar(monthly_balance['Month'], monthly_balance['Value'])
    plt.title(f"Monthly Balance for {customer_info}")
    plt.xlabel("Month")
    plt.ylabel("Balance")
    plt.grid()
    plt.show()

def plot_entries_between_dates(df, customer_info, start_date, end_date):
    df = df.copy()
    df['Date'] = pd.to_datetime(dict(year=2025, month=df['Month'], day=df['Day']))

    customer_df = df[(df["Name"] == customer_info) | (df["ID"] == customer_info)]
    if customer_df.empty:
        print(f"No entries found for customer: {customer_info}")
        return

    mask = (customer_df['Date'] >= pd.to_datetime(start_date)) & \
           (customer_df['Date'] <= pd.to_datetime(end_date))
    filtered = customer_df[mask]

    if filtered.empty:
        print(f"No entries for {customer_info} between {start_date} and {end_date}.")
        return

    plt.figure()
    plt.scatter(filtered['Date'], filtered['Value'], marker='o')
    plt.title(f"Entries for {customer_info}\n{start_date}  {end_date}")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid()
    plt.show()

def plot_negative_transactions_between_dates(df, start_date, end_date):
    df = df.copy()
    df['Date'] = pd.to_datetime(dict(year=2025, month=df['Month'], day=df['Day']))

    mask = (df['Date'] >= pd.to_datetime(start_date)) & \
           (df['Date'] <= pd.to_datetime(end_date))
    filtered = df[mask]

    negative_df = filtered[filtered['Value'] < 0]

    if negative_df.empty:
        print(f"No negative transactions found between {start_date} and {end_date}.")
        return

    plt.figure()
    plt.scatter(negative_df['Date'], negative_df['Value'], marker='o')
    plt.title(f"Negative Transactions\n{start_date} to {end_date}")
    plt.xlabel("Date")
    plt.ylabel("Negative Value")
    plt.grid()
    plt.show()
